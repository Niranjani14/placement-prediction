document.querySelectorAll('input[type=range]').forEach(r => {
  const out = document.getElementById(r.id + '_val');
  if (out) { out.textContent = r.value; r.addEventListener('input', () => out.textContent = r.value); }
});
const rf = document.getElementById('registerForm');
if (rf) rf.addEventListener('submit', e => {
  if (rf.password.value.length < 6) { alert('Password must be at least 6 characters'); e.preventDefault(); }
  else if (rf.password.value !== rf.confirm.value) { alert('Passwords do not match'); e.preventDefault(); }
});
