import os
import sqlite3
from functools import wraps

import joblib
import pandas as pd
from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, jsonify, g)
from werkzeug.security import generate_password_hash, check_password_hash

from train_model import train, FEATURES, MODEL_PATH, DATA_PATH

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB = "database.db"

SKILLS = {
    "cgpa": ("CGPA", "Focus on core subjects and aim for a consistent 8+ CGPA."),
    "internships": ("Internships", "Apply for internships on Internshala, LinkedIn or via college TPO."),
    "projects": ("Projects", "Build 2-3 end-to-end projects and host them on GitHub."),
    "certifications": ("Certifications", "Complete certifications (Coursera, NPTEL, AWS, Google)."),
    "aptitude": ("Aptitude", "Practise quantitative, logical and verbal tests daily."),
    "communication": ("Communication", "Join mock interviews, GDs and presentation practice."),
    "coding": ("Coding", "Solve DSA problems on LeetCode/HackerRank regularly."),
}

_model = None


def get_model():
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else train()
    return _model


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db:
        db.close()


def init_db():
    db = sqlite3.connect(DB)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS predictions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        cgpa REAL, tenth REAL, twelfth REAL, internships REAL, projects REAL,
        certifications REAL, aptitude REAL, communication REAL, coding REAL, backlogs REAL,
        probability REAL, result TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
    """)
    db.commit()
    db.close()


def login_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if "user_id" not in session:
            flash("Please login first.", "error")
            return redirect(url_for("login"))
        return f(*a, **k)
    return wrapper


@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        pw = request.form["password"]
        if len(pw) < 6:
            flash("Password must be at least 6 characters.", "error")
            return redirect(url_for("register"))
        try:
            get_db().execute("INSERT INTO users(name,email,password) VALUES (?,?,?)",
                             (name, email, generate_password_hash(pw)))
            get_db().commit()
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email already registered.", "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password"], request.form["password"]):
            session["user_id"], session["name"] = user["id"], user["name"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    rows = get_db().execute("SELECT * FROM predictions WHERE user_id=? ORDER BY id DESC",
                            (session["user_id"],)).fetchall()
    return render_template("dashboard.html", history=rows, latest=rows[0] if rows else None)


@app.route("/predict", methods=["GET", "POST"])
@login_required
def predict():
    result = None
    if request.method == "POST":
        try:
            vals = {f: float(request.form[f]) for f in FEATURES}
        except (KeyError, ValueError):
            flash("Please fill all fields with valid numbers.", "error")
            return redirect(url_for("predict"))
        X = pd.DataFrame([vals], columns=FEATURES)
        prob = float(get_model().predict_proba(X)[0][1])
        label = "Likely to be Placed" if prob >= 0.5 else "Needs Improvement"
        cols = ",".join(FEATURES)
        qs = ",".join("?" * len(FEATURES))
        db = get_db()
        db.execute(f"INSERT INTO predictions(user_id,{cols},probability,result) VALUES (?,{qs},?,?)",
                   [session["user_id"], *[vals[f] for f in FEATURES], prob, label])
        db.commit()
        result = {"prob": round(prob * 100, 1), "label": label}
    return render_template("predict.html", result=result)


@app.route("/skill-gap")
@login_required
def skill_gap():
    row = get_db().execute("SELECT * FROM predictions WHERE user_id=? ORDER BY id DESC LIMIT 1",
                           (session["user_id"],)).fetchone()
    if not row:
        return render_template("skill_gap.html", gaps=None)
    get_model()
    df = pd.read_csv(DATA_PATH)
    bench = df[df.placed == 1][list(SKILLS)].mean()
    gaps = []
    for k, (label, tip) in SKILLS.items():
        you, target = float(row[k]), round(float(bench[k]), 2)
        gaps.append({"skill": label, "you": you, "target": target,
                     "gap": round(max(target - you, 0), 2),
                     "status": "Good" if you >= target else "Gap", "tip": tip,
                     "pct": round(min(you / target * 100, 100), 1)})
    return render_template("skill_gap.html", gaps=gaps)


@app.route("/analytics")
@login_required
def analytics():
    return render_template("analytics.html")


@app.route("/api/analytics")
@login_required
def api_analytics():
    model = get_model()
    df = pd.read_csv(DATA_PATH)
    by_intern = df.groupby("internships")["placed"].mean().mul(100).round(1)
    bins = pd.cut(df.cgpa, [0, 6, 7, 8, 9, 10], labels=["<6", "6-7", "7-8", "8-9", "9-10"])
    by_cgpa = df.groupby(bins, observed=True)["placed"].mean().mul(100).round(1)
    imp = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False).round(3)
    return jsonify({
        "total": int(len(df)), "placed": int(df.placed.sum()),
        "rate": round(float(df.placed.mean() * 100), 1),
        "avg_cgpa_placed": round(float(df[df.placed == 1].cgpa.mean()), 2),
        "intern": {"labels": [str(i) for i in by_intern.index], "values": by_intern.tolist()},
        "cgpa": {"labels": [str(i) for i in by_cgpa.index], "values": by_cgpa.tolist()},
        "importance": {"labels": imp.index.tolist(), "values": imp.tolist()},
    })


if __name__ == "__main__":
    init_db()
    get_model()
    app.run(debug=True)
