import os
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

DATA_PATH = "data/placement_data.csv"
MODEL_PATH = "model/placement_model.pkl"
FEATURES = ["cgpa", "tenth", "twelfth", "internships", "projects",
            "certifications", "aptitude", "communication", "coding", "backlogs"]


def generate_data(n=1000, seed=42):
    """Synthetic dataset. Replace data/placement_data.csv with a real dataset
    (same columns + 'placed' = 0/1) for real-world results."""
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "cgpa": np.clip(rng.normal(7.2, 1.0, n), 4, 10).round(2),
        "tenth": np.clip(rng.normal(75, 10, n), 45, 100).round(1),
        "twelfth": np.clip(rng.normal(72, 10, n), 45, 100).round(1),
        "internships": rng.integers(0, 4, n),
        "projects": rng.integers(0, 6, n),
        "certifications": rng.integers(0, 6, n),
        "aptitude": np.clip(rng.normal(65, 15, n), 20, 100).round(1),
        "communication": np.clip(rng.normal(6, 1.8, n), 1, 10).round(1),
        "coding": np.clip(rng.normal(6, 1.8, n), 1, 10).round(1),
        "backlogs": rng.choice([0, 1, 2, 3], n, p=[.7, .15, .1, .05]),
    })
    score = (0.9 * (df.cgpa - 7) + 0.03 * (df.aptitude - 65) + 0.45 * df.internships
             + 0.2 * df.projects + 0.15 * df.certifications + 0.25 * (df.communication - 6)
             + 0.3 * (df.coding - 6) - 0.8 * df.backlogs + rng.normal(0, 0.8, n) - 0.8)
    prob = 1 / (1 + np.exp(-score))
    df["placed"] = (rng.random(n) < prob).astype(int)
    return df


def train():
    os.makedirs("data", exist_ok=True)
    os.makedirs("model", exist_ok=True)
    df = pd.read_csv(DATA_PATH) if os.path.exists(DATA_PATH) else generate_data()
    df.to_csv(DATA_PATH, index=False)
    df = df.dropna()
    X, y = df[FEATURES], df["placed"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    model = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42)
    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)
    print("Accuracy:", round(accuracy_score(y_te, pred), 3))
    print(classification_report(y_te, pred))
    joblib.dump(model, MODEL_PATH)
    return model


if __name__ == "__main__":
    train()
